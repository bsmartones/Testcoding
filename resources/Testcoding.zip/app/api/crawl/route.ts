import { NextRequest, NextResponse } from 'next/server';
import { PlaywrightCrawler } from 'crawlee';
import { parseStringPromise } from 'xml2js';
import fetch from 'node-fetch';

export async function POST(req: NextRequest) {
    const { url } = await req.json();

    if (!url) {
        return NextResponse.json({ error: 'Invalid URL' }, { status: 400 });
    }

    try {
        const crawler = new PlaywrightCrawler({
            async requestHandler({ page, request, enqueueLinks, log }) {
                const content = await page.content();

                log.info(`Crawling homepage of ${request.url}`);

                await enqueueLinks({
                    options: { url },
                });

                return {
                    homepageContent: content,
                };
            },
        });

        let homepageContent = '';
        await crawler.run([url]).then((results) => {
            homepageContent = results[0]?.homepageContent || '';
        });

        const sitemapUrl = `${url}/sitemap.xml`;
        const sitemapResponse = await fetch(sitemapUrl);

        let sitemapUrls: string[] = [];
        if (sitemapResponse.ok) {
            const sitemapXml = await sitemapResponse.text();
            const sitemapData = await parseStringPromise(sitemapXml);
            sitemapUrls = sitemapData.urlset.url.map((entry: any) => entry.loc[0]);
        }

        return NextResponse.json({ homepageContent, sitemapUrls });
    } catch (err) {
        console.error(err);
        return NextResponse.json({ error: 'Error crawling website' }, { status: 500 });
    }
}
