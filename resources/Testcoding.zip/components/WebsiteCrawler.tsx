import { useState } from 'react';

const WebsiteCrawler = () => {
    const [url, setUrl] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [data, setData] = useState(null);
    const [error, setError] = useState('');

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setUrl(e.target.value);
    };

    const handleCrawl = async () => {
        setIsLoading(true);
        setError('');
        setData(null);

        try {
            const response = await fetch('/api/crawl', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ url }),
            });

            if (!response.ok) {
                throw new Error('Failed to crawl the website');
            }

            const result = await response.json();
            setData(result);
        } catch (err) {
            setError(err.message);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div>
            <h1>Website Crawler</h1>
            <input
                type="text"
                placeholder="Enter website URL"
                value={url}
                onChange={handleInputChange}
            />
            <button onClick={handleCrawl} disabled={!url || isLoading}>
                {isLoading ? 'Crawling...' : 'Crawl Website'}
            </button>

            {error && <p style={{ color: 'red' }}>{error}</p>}
            {data && (
                <div>
                    <h2>Homepage Content</h2>
                    <pre>{data.homepageContent}</pre>
                    
                    <h2>Sitemap URLs</h2>
                    <ul>
                        {data.sitemapUrls.map((sitemapUrl: string, idx: number) => (
                            <li key={idx}>{sitemapUrl}</li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default WebsiteCrawler;
